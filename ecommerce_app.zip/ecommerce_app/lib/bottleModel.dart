class Bottle{
  final String image;
  final String typeOfBottle;
 final String cost;
  const Bottle({
    required this.image,
    required this.typeOfBottle,
    required this.cost,
});
}