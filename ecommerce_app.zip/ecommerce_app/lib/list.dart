import 'bottleModel.dart';

List<Bottle> bottleObjs = [
  Bottle(image: 'assets/flask.jpeg', typeOfBottle: 'Hydro-Flask', cost: '\$10.50'),
  Bottle(image: 'assets/tupperware.jpg', typeOfBottle: 'Tupperware', cost: '\$10.50'),
  Bottle(image: 'assets/Kipsta.jpg', typeOfBottle: 'Kipsta(new)', cost: '\$10.50'),
  Bottle(image: 'assets/Biking.jpg', typeOfBottle: 'Biker-Bottle', cost: '\$10.50'),
];
